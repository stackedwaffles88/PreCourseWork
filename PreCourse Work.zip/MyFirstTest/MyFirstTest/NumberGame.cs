﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstTest
{
    class NumberGame
    { 
          static void Main(string[] args)
        {
            
            Random r = new();
            int gameNumber = r.Next(1, 10);
            
            START:
            Console.WriteLine("Choose a number between 1 and 10.");
            var userAnswer1 = Convert.ToInt32(Console.ReadLine());
            bool userAnswer = Convert.ToBoolean(Console.ReadLine());

            if (userAnswer1 < gameNumber)
            {
                Console.WriteLine("Sorry, that's too low! Try again.");
                Console.ReadLine();
                goto START;
            }
            else if (userAnswer1 > gameNumber)
            {
                Console.WriteLine("Sorry, that's too high! Try again.");
                Console.ReadLine();
                goto START;
            }
            else
            {
                Console.WriteLine("Congratulations, You Win!");

            }

            Console.WriteLine("Want to play again?");
            Console.ReadLine();

            if (userAnswer == true)
            {
                Console.WriteLine("Get Ready!");
                goto START;
            }

            
            
            
            
       
        }
    
        
    }
}
