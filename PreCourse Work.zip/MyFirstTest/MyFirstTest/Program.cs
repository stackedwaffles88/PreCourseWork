﻿using System;


namespace MyFirstTest
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int age;
            string name;
            

            Console.WriteLine("Enter your name: ");
            name = Console.ReadLine();
            Console.WriteLine($"Hello {name}!");

            Console.WriteLine("Enter your age: ");
            age = Convert.ToInt32(Console.ReadLine());

            if (age >= 30)
            {
                Console.WriteLine($"{name} You are old!");
            }
            else
            {
                Console.WriteLine($"{name}, You are not old!");
            }
            Console.WriteLine("Do you want to play a game?");


            Program game = new Program();
            Random r = new();
            int gameNumber = r.Next(1, 10);


        START:
            Console.WriteLine("Choose a number between 1 and 10.");
            var userAnswer1 = Convert.ToInt32(Console.ReadLine());


            if (userAnswer1 < gameNumber)
            {
                Console.WriteLine("Sorry, that's too low! Try again.");
                goto START;

            }
            else if (userAnswer1 > gameNumber)
            {
                Console.WriteLine("Sorry, that's too high! Try again.");
                goto START;

            }
            else
            {
                Console.WriteLine("Congratulations, You Win!");

            }



            //Console.WriteLine("Want to play again?");
            //Console.ReadLine();

            //if (userAnswer == true)
            //{
            //    Console.WriteLine("Get Ready!");
            //    goto START;
            //}

        }
    }
}
